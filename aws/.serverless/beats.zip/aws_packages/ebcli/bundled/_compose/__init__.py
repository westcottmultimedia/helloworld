from __future__ import unicode_literals
from .service import Service  # noqa:flake8

__version__ = '1.3.0dev'
